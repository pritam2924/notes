package Arrays;

public class maxele {
    static int Maxele(int [] a){
        int max=a[0];
        for(int i:a){
            if(i>max){
                max=i;
            }

        }
        return max;
    }
    public static void main(String[] args) {
        int [ ] m={1,2,300,4,5,6};
        System.out.println(Maxele(m));

    }
}
