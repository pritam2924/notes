package Arrays;

public class avg {
    static int average(int[] a ){
        int count=0;
        int avg=0;

        for(int i : a){
            count+=i;



        }
        avg=count/a.length;
        return avg;

    }
    public static void main(String[] args) {
        int[] num={1,2,3,4,5};
        System.out.println(average(num));

    }
}
