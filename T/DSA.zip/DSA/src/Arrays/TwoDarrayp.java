package Arrays;

import java.util.ArrayList;
import java.util.List;

public class TwoDarrayp {
    //sum of each row in an two d array
    static void SUmoftwod(int[][] arr){
        int n= arr.length;
        List<Integer> array=new ArrayList<>();

        for(int i=0;i<n;i++){
            int sum=0;
            for(int j=0;j<arr[i].length;j++){
                sum+=arr[i][j];


            }
            array.add(sum);

        }
        System.out.println(array);

    }
    //sum of column in an two d array
    static void Sumofcol(int[][ ] arr){
        List<Integer> neww=new ArrayList<>();
        for(int i=0;i<arr.length;i++){
            int sum=0;
            for(int j=0;j< arr[0].length;j++){
                sum+=arr[j][i];

            }
            neww.add(sum);
        }
        System.out.println(neww);
    }

    //wave print a matrix ega edrag ond colum top to bottom print adra ennond column bottom to top print agbaek
    //so ega even coloumn yalla top to bottm
    //odd column yalla bottom to top
    static  void Waveprint(int[][] arr){
        int n=arr.length;
        int m=arr[0].length;
        for(int i=0;i<m;i++){
                if(i%2==0) {
                    for (int j = 0; j < n; j++) {
                        System.out.print(arr[j][i]);
                    }
                }
                else {
                    System.out.println("hello");

                    for(int j=n-1;j>=0;j--){
                        System.out.println(arr[j][i]);
                    }
                }

            }
        }

        //trNSPOSE Of matrix
    static int[][] Transpose(int [][] arr){
        int n=arr.length;
        int m=arr[0].length;
        int[][] newarr=new int[n][m];
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                newarr[j][i]=arr[i][j];
            }
        }
        return newarr;
    }
    //eda rotate matrix or image anth heli question edrage pura element 90 degree change madabek
    //like like row edid first column agabek same hanga
    //eda solve madabek anth andra first matrix da transpose madabek amel adan reverse madabek only column asta
    static int[][] Rotatematrix(int[][] arr){
        int n=arr.length;
        int m=arr[0].length;
        int[][] newarr=new int[m][n];
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                newarr[j][i]=arr[i][j];
            }
        }
        for(int i=0;i<n;i++){
            int s=0;
            int e=m-1;
            while(s<=e){
                int temp=newarr[i][s];
                newarr[i][s]=newarr[i][e];
                newarr[i][e]=temp;
                s++;
                e--;


            }
        }

        return newarr;


    }

    //spiral of matrix for more information refer to the document notes
    static void Sprialmatrix(int [][] arr){
        int row=arr.length;
        int col=arr[0].length;
        int srow=0;
        int endrow=row-1;
        int scol=0;
        int endcol=col-1;
        while(srow<=endrow && scol<=endcol){
            //we must trace from right to left so row const and change col
            for(int i=scol;i<=endcol;i++){
                System.out.print(arr[srow][i]+" ");
            }
            srow++;
            System.out.println();
            //he we are are tracing the column from top to bottom to col constant and row change
            for(int i=srow;i<=endrow;i++){
                System.out.print(arr[i][endcol] +" ");

            }
            endcol--;
            System.out.println();
            //here we are tracing from right to left to rwo wil be constant and col change
            for(int i=endcol;i>=scol;i--){
                System.out.print(arr[endrow][i]+" ");

            }
            System.out.println();
            endrow--;
            //here we are tracing from bottom to top col const and row change
            for(int i=endrow;i>=srow;i--){
                System.out.print(arr[i][scol]+" ");
            }
            System.out.println();
            scol++;
        }
    }
    //bubble sort for more info refer to notes
    static  void Bubblesort(int [] arr){
        int n=arr.length;
        for(int i=0;i<n-1;i++){
            for(int j=0;j<n-i-1;j++){
                if(arr[j]>arr[j+1]){
                    int temp=arr[j];
                    arr[j]=arr[j+1];
                    arr[j+1]=temp;
                }
            }
        }
        for(int i: arr){
            System.out.print(i+" ");
        }
    }
    //selection sort
    static void Selection(int [] arr){
        int n=arr.length;
        for(int i=0;i<n-1;i++){
            int mini=i;
            for(int j=i+1;j<n;j++){
                if(arr[mini]>arr[j]){
                    mini=j;

                }
            }
            int temp=arr[i];
            arr[i]=arr[mini];
            arr[mini]=temp;
        }
        for(int i:arr){
            System.out.println(i);
        }
    }
    public static void main(String[] args) {
        int[] arr= {9,4,5,6,2,1,3,8};
//        SUmoftwod(arr);
//        Sprialmatrix(arr);
//        int[][] x=Rotatema
//        trix(arr);
        Selection(arr);
//        int n=x.length;
//        int m=x[0].length;
//        for(int i=0;i<n;i++){
//            for(int j=0;j<m;j++){
//                System.out.print(x[i][j]+" ");
//            }
//            System.out.println();
//        }
//        Sumofcol(arr);
//        Waveprint(arr);
    }

}
