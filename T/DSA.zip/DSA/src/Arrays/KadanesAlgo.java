package Arrays;

import java.util.ArrayList;
import java.util.List;

public class KadanesAlgo {
    static void Maxsubarray(int []arr){
        List<Integer> subarr=new ArrayList<>();
        int n=arr.length;
        int sum=0;
        int maxi=Integer.MIN_VALUE;//eda yak pa ant handra starting smallest element considwer madak
        for(int i=0;i<n;i++){
            sum+=arr[i];
            maxi=Math.max(maxi,sum);
            if(sum<0){
                sum=0;
            }


        }
        System.out.println(sum);
        System.out.println(subarr);
    }
    public static void main(String[] args) {
        int[] m={-2,1,-3,4,-1,2,1,-5,4};
        Maxsubarray(m);

    }
}
