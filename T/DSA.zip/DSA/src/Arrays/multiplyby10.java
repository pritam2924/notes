package Arrays;

public class multiplyby10 {
    static int[] multiply(int[ ] n){
        int size=n.length;
        int[] b = new int[size];
        int a;
        for(int i=0;i<size;i++){
            a=n[i];
            int newele=a*10;
            b[i]=newele;
        }
        return b;
    }
    public static void main(String[] args) {
        int[] a={1,2,3,4,5};
        int [] m=multiply(a);
        for(int i:m){
            System.out.println(i);
        }
    }
}
