package Arrays;

public class sumofposandneg {
    static int[] Sum(int[] a){
        int[] v=new int[2];
        int sump = 0;
        int sumn=0;
        for(int i:a){
            if(i>0){
                sump+=i;
            }
            else {
                sumn+=i;
            }
        }
        v[0]=sumn;
        v[1]=sump;
        return v;

    }
    public static void main(String[] args) {
        int[] a={-1,1,2,-2,3,-4,5,-6};
        int[]m=Sum(a);
        System.out.println("posivite" + m[1]);
        System.out.println("negative" + m[0]);

    }
}
