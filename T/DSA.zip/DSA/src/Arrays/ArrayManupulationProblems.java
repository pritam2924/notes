package Arrays;

public class ArrayManupulationProblems {
    static void printalt(int n[]){
        int i=0;
        int j=n.length-1;
        while(i<j){
            if(i==j){
                System.out.println(n[i]);
            }
            else{
                System.out.println(n[i]);
                i++;
                System.out.println(n[j]);
                j--;

            }

        }

    }

    //find the mode of the number
    static void modecal(int arr[]){
        int s=arr.length;
        int count=0;
        for(int i=0;i<s;i++){
            for(int j=i;j<s;j++){
                int c=0;
                if(arr[i]==arr[j]){


                }


            }
        }

                System.out.println(count);
    }
    public static void main(String[] args) {
        int [] a={1,2,2,2,23,3,3,5,5,5,5,5,5,5,3,4,5,6};
        modecal(a);

    }
}
