package Arrays;

public class LinearSeach {
    static int Search(int [] a,int ele){
        int m=0;
        for(int i=0;i<a.length;i++){
            if(a[i]==ele){
                m=i;
            }

        }
        return m;

    }
    public static void main(String[] args) {
        int[ ] a={1,2,3,4,5,6};
        int s=5;
        System.out.println(Search(a,s));


    }
}
