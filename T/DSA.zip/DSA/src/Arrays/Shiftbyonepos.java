package Arrays;

public class Shiftbyonepos {
    static void shift(int [] n){
        int size=n.length;

        int temp=n[size-1];

        for(int i=size-1;i>0;i--){
            n[i]=n[i-1];

        }
        n[0]=temp;

    }

    public static void main(String[] args) {
        int [] a={1,2,3,4,5,6};
        shift(a);
        for(int i:a){
            System.out.println(i);
        }



    }
}
