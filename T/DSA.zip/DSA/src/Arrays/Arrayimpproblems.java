package Arrays;

import java.util.ArrayList;
import java.util.List;

public class Arrayimpproblems {

    // sort 0 and 1 in an array
    //one method is by using colection

    //normal method le try madbek andra ond logic form madbek
    static void sortzeroandone(int[] arr){

        int n=arr.length;
        int i=0;
        int j=n-1;
        while(i<j){
            if(arr[i]==1 && arr[j]==0){
                arr[i]=0;
                arr[j]=1;
            }
            if(arr[i]==0){
                i++;
            }
            if(arr[j]==1){
                j--;
            }

        }
        for(int m:arr){
            System.out.print(m);

        }
    }


    //find the missing numbr in an arrary
    static void Findmissingnumber(int [] arr){
        int n=arr.length;
        int sum=0;
        for(int i=0;i<=n;i++){
            sum+=i;
        }
        int arrsum=0;
        for(int i:arr){
            arrsum+=i;
        }
        int result=sum-arrsum;
        System.out.println(sum);
        System.out.println(arrsum);
        System.out.println(result);

    }

    //find uniuq element we will use xor here  xor is like bettween two element and it will
    //give us unique elemt we can do this for missing number also
    static void findunique(int [] arr){
        int xorSum=0;
        for(int i: arr){
            xorSum=xorSum ^i;
        }
        System.out.println(xorSum);
    }
    //this is type of two sum problem
    //in this problem we should find the pair whose total wil be equal to the sum
    static int[] PairSum(int [] arr){
        int n=arr.length;
        int sum=5;

        for(int i=0;i<n;i++){
            for(int j=0;j<i;j++){
                if(arr[i]+arr[j]==sum){
                    int[] newarr={i,j};
                    return newarr;


                }

            }
        }
        int[] newarr={};
        return newarr;

    }

    //this is three sum problem
    //same find three number which match the sum
    static void Threesum(int[] arr){

        int n=arr.length;
        int sum=15;
        for(int i=0;i<n;i++){
            for(int j=0;j<i;j++){
                for(int p=0;p<j;p++){
                    if(arr[i]+arr[j]+arr[p]==sum){
                        System.out.println(arr[i]+","+arr[j]+","+arr[p]);
                    }

                }
            }
        }
    }

    //remove dupplicate element from the sorted array
    //we can do this by two ways
    //one is using hashmapp finding element count and print only single element
    //using two pointer technique which i am doing now
    static void Removedup(int arr[]){
        int i=0;
        int j=1;
        int s=arr.length;
        while(j<s){
            if(arr[i]==arr[j]){
                j++;
            }
            else{
                i++;
                arr[i]=arr[j];
                j++;
            }

        }
        for(int p:arr){
            System.out.println(p);
        }
    }


    //find the first repeating element
    static int Firstrep(int arr[]){
        int s=arr.length;
        int ele=0;
        for(int i=0;i<s;i++){
            for(int j=0;j<i;j++){
                if(arr[i]==arr[j]){
                    ele=arr[i];
                    return ele;
                }
            }
        }
        return ele;
    }

    //this is beautiful qiestion and the nae of the question is to find PIVOT index
    //pivot index means the number in array where its sum of left and sum of right must be equal
    //we can solve this by brute force by going to each element and do it but it will take O(n^2) TC
    //so we will caluclate sumof the array from left and sum of array from right and will match the index whihc have same sum
    static int Pivotindex(int arr[]){
        int n=arr.length;
        int[] arr1=new int[n];
        int[] arr2=new int[n];
        int result=0;
        int count1=0;
        int count2=0;
        for(int i=0;i<n;i++){
            //left
            count1+=arr[i];
            arr1[i]=count1;
        }
//        for(int i:arr1){
//            System.out.print(i+",");
//        }
        for(int i=n-1;i>0;i--){
            //left
            count2+=arr[i];
            arr2[i]=count2;
        }
//        for(int i:arr2){
//            System.out.print(i+",");
//        }
        for(int i=0;i<n;i++){
            if(arr1[i]==arr2[i]){
                result=arr[i];
            }
        }
        return result;



    }//sexy u solved it good boi
    public static void main(String[] args) {
        int[] m={1,7,3,6,5,6};
//        sortzeroandone(m);
//        Findmissingnumber(m);
//         findunique(m);
//        Threesum(m);
//        Removedup(m);
        System.out.println(Pivotindex(m));

//        System.out.println(Firstrep(m));?
//        int n[]=PairSum(m);
//

    }
}
