package Arrays;
//another method is by swaping the last and the first element with i and j and the ncontinuing this for same

public class Reverse {
    static int[ ] reverse(int[] a){
        int [] n=new int[a.length];

        for(int i=0;i<a.length;i++){
            int newe=a[i];
            n[a.length-i-1]=a[i];


        }
        return n;

    }
    public static void main(String[] args) {
        int[] a={1,2,3,4,5,6};
        int [] b=reverse(a);
        for(int i:b){
            System.out.print(i);
        }


    }
}
