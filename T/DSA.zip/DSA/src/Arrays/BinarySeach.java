package Arrays;

public class BinarySeach {

    //1.
    static int BS(int[] arr, int t) {
        int n = arr.length;
        int s = 0;
        int e = n - 1;
        int ele = 0;
        while(s<=e) {
            int mid = (s + e) / 2;
            if (arr[mid] == t) {
                ele = mid;
            }
            else if (t < arr[mid]) {
                e = mid - 1;
            }
            else if(t > arr[mid]){
                s = mid + 1;

            }
            else{
                System.out.println("No element found byebye ");
            }
        }


        return ele;
    }
    //2.
    //this is binary search problem where we have to find the target in an sorted arrray and count number of times it has occured
    static int Bslbubproblem(int[] arr,int t){
        int n=arr.length;
        int s1=0;
        int s2=0;
        int e1=n-1;
        int e2=n-1;
        int lb=0;
        int ub=n;

        // elle nav lowerbound hudakatevi like yavad lowest occurance of target pa anth
        while(s1<=e1){
            int mid=(s1+e1)/2;
            if(arr[mid]>=t){
                lb=mid;
                e1=mid-1;
            }
            else{
                s1=mid+1;
            }
        }
        //elle nav upper bound hudakatevi like target kina next element jasti edid yad pa anth
       while(s2<e2){
           int mid=(s2+e2)/2;
           if(arr[mid]<=t){
               s2=mid+1;
           }
           else{
               ub=mid;
               e2=mid-1;
           }
       }



        //ega ad ub math lb minus madidra count sigatethi
        int count=ub-lb;
        return count;
        //eda condition edag ye namdabek anth thilko
//        int[] arr={8,9,10,11,12,12,12};
    }



    //3.
    //Peak of mountain array problem
    //elle ond number highes eratethi like array will be
    //[1,3,5,4,2] elle peak erud 5 so arar index return madabek
    static  int Peakmountain(int[] arr){
        int n=arr.length;
        int s=0;
        int e=n-1;
        int ele=0;
        while(s<=e){
            int mid=(s+e)/2;
            if(arr[mid]>=arr[mid+1]){
                ele=mid;
                e=mid-1;
            }
            else {
                s=mid+1;
            }
        }
        return ele;
    }



    //4
    //pivor in dex problem
    // arr={50,60,70,10,20,30,40} ega yalinda sudden change agethi adak pivot antar
    // so ega pivot index hudakbek nav
    static  int Pviot(int[] arr,int t){
        int n=arr.length;
        int s=0;
        int e=n-1;
        int ans=0;
        int index=0;
        while(s<=e){
            int mid=(s+e)/2;
            if(arr[mid]<=arr[n-1]){
                e=mid-1;
            }
            else{
                ans=mid;
                s=mid+1;
            }
        }
        //eda secound problem yen paanth andra eda roated sorted array dag hudak bek element
        //so adak nav yerad part togotevi array dag ond starting inda pivot index mata
        //ennond pura asending order da
        // so ada target element < starting and leass than pviot edra first set dag hudakud or else secound set
        
        if(t>=arr[0] && t<=arr[ans]){
            int s1=0;
            int e1=ans;
            while(s1<=e1){
                int mid=(s1+e1)/2;
                if(arr[mid]<=t){
                    index=mid;
                    s1=mid+1;

                }
                else{
                    e1=mid-1;
                }
            }
        }
        else{
            int s1=ans+1;
            int e1=n-1;
            while(s1<=e1){
                int mid=(s1+e1)/2;
                if(arr[mid]<=t){
                    index=mid;
                    s1=mid+1;

                }
                else{
                    e1=mid-1;
                }
            }

        }
        return index;
    }
    static void main(String[] args) {
        int[] a={50,60,70,80,90,100,10,20,30,40};
        System.out.println(Pviot(a,10));


    }

}
